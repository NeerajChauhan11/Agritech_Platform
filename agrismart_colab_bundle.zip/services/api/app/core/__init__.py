"""Core configuration and constants."""
