"""AgriSmart API Application Package."""
